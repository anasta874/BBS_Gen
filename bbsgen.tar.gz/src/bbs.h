#ifndef BBS_H
#define BBS_H

#include <stdint.h>

uint64_t bbs_next(uint64_t *state, uint64_t n);

#endif // BBS_H
